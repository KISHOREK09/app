-- MySQL dump 10.13  Distrib 9.0.1, for macos14.4 (arm64)
--
-- Host: localhost    Database: spermdetect
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `count`
--

DROP TABLE IF EXISTS `count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `count` (
  `uid` int NOT NULL,
  `active_sperm1` int NOT NULL,
  `active_sperm2` int DEFAULT NULL,
  `active_sperm3` int DEFAULT NULL,
  `active_sperm4` int DEFAULT NULL,
  `active_sperm5` int DEFAULT NULL,
  `active_sperm6` int DEFAULT NULL,
  PRIMARY KEY (`uid`),
  CONSTRAINT `count_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `patient` (`uid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `count`
--

LOCK TABLES `count` WRITE;
/*!40000 ALTER TABLE `count` DISABLE KEYS */;
INSERT INTO `count` VALUES (19,26,NULL,NULL,NULL,NULL,NULL),(21,2,13,28,85,24,26),(28,138,NULL,NULL,NULL,NULL,NULL),(31,6060,984,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `age` int NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `bmi` float NOT NULL,
  `foc` int NOT NULL,
  `sexual_dysfunction` varchar(20) NOT NULL,
  `alcoholic` varchar(10) NOT NULL,
  `smoker` varchar(10) NOT NULL,
  `drugs` varchar(10) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (18,'kishore',22,'student',1.7,55.3,19.1349,2,'no','Yes','No','No'),(19,'vignesh',21,'student',1.7,50.4,17.4394,3,'no','Yes','Yes','Yes'),(20,'varun',20,'student',1.5,70.5,31.3333,3,'no','Yes','Yes','Yes'),(21,'tamil',32,'IT',1.7,89.2,30.8651,3,'no','Yes','No','No'),(22,'hanush',20,'student',1.79,52,16.2292,1,'no','No','Yes','No'),(25,'muthu',31,'IT',1.5,78.6,34.9333,2,'no','Yes','Yes','No'),(26,'Kishore k',22,'student',1.6,55.2,21.5625,2,'no','Yes','Yes','No'),(27,'prabhu',36,'IT',1.7,60.8,21.0381,2,'no','Yes','No','No'),(28,'prithvi',33,'IT',1.7,67.5,23.3564,3,'no','Yes','No','No'),(29,'rahul',24,'student',1.4,54.2,27.6531,2,'no','Yes','No','No'),(30,'krishna',22,'student',1.6,65.4,25.5469,2,'no','No','No','No'),(31,'vinoth',21,'nik',2.3,90.3,17.0699,2,'no','Yes','No','No');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `result` (
  `uid` int NOT NULL,
  `sample1` varchar(255) DEFAULT NULL,
  `sample2` varchar(255) DEFAULT NULL,
  `sample3` varchar(255) DEFAULT NULL,
  `sample4` varchar(255) DEFAULT NULL,
  `sample5` varchar(255) DEFAULT NULL,
  `sample6` varchar(255) DEFAULT NULL,
  `current_sample` int DEFAULT '1',
  PRIMARY KEY (`uid`),
  CONSTRAINT `result_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `patient` (`uid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES (19,'/Users/kishore/Desktop/app/processed_images/sample1_19.png',NULL,NULL,NULL,NULL,NULL,2),(21,'/Users/kishore/Desktop/app/processed_images/sample1_21.png','/Users/kishore/Desktop/app/processed_images/sample2_21.png','/Users/kishore/Desktop/app/processed_images/sample3_21.png','/Users/kishore/Desktop/app/processed_images/sample4_21.png','/Users/kishore/Desktop/app/processed_images/sample5_21.png','/Users/kishore/Desktop/app/processed_images/sample6_21.png',6),(28,'/Users/kishore/Desktop/app/processed_images/sample1_28.jpg',NULL,NULL,NULL,NULL,NULL,2),(31,'/Users/kishore/Desktop/app/processed_images/sample1_31.jpg','/Users/kishore/Desktop/app/processed_images/sample2_31.jpg',NULL,NULL,NULL,NULL,3);
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signup` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup`
--

LOCK TABLES `signup` WRITE;
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` VALUES (11,'kishore','123@123','$2b$12$oNMSp3onlTwyPMSriok1JuiXiZB/B3KzEn4DTDFr85aFWRa/2nHTC');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-03 13:55:52
